﻿namespace VaporStore.Data
{
	public static class Configuration
	{
		public static string ConnectionString =
			@"Server=DESKTOP-LQCF567\SQLEXPRESS;Database=VaporStore;Trusted_Connection=True";
	}
}