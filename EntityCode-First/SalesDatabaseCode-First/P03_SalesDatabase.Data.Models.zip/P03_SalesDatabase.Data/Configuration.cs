﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P03_SalesDatabase.Data
{
    public static class Configuration
    {
        public static string Connection = @"Server=DESKTOP-LQCF567\SQLEXPRESS;Database=SalesDatabase;Integrated Security=True;";
    }
}
