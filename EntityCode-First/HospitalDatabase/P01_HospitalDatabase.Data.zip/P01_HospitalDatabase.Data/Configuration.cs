﻿using System;
using System.Collections.Generic;
using System.Text;

namespace P01_HospitalDatabase.Data
{
    public static class Configuration
    {
        public static string Connection = @"Server=DESKTOP-LQCF567\SQLEXPRESS;Database=HospitalDatabase;Integrated Security=True;";
    }
}
